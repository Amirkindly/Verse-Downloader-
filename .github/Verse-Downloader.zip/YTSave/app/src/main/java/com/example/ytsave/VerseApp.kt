package com.example.ytsave

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/** آماده‌سازی موتور دانلود یک بار و در پس‌زمینه (هم‌زمان با صفحه‌ی ورود) */
object Engine {
    val ready = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
}

class VerseApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                Engine.ready.value = true
            } catch (e: Exception) {
                Engine.error.value = e.message ?: "unknown"
            }
        }
    }
}
