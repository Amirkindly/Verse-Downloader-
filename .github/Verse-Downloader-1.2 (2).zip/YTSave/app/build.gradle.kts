plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// هسته‌ی Xray (موتور V2Ray) در زمان بیلد از ریلیز رسمی دانلود و به‌شکل libxray.so داخل APK گذاشته می‌شود
val xrayOut = layout.buildDirectory.dir("xray-jni").get().asFile
val downloadXray by tasks.registering {
    outputs.dir(xrayOut)
    doLast {
        val base = "https://github.com/XTLS/Xray-core/releases/latest/download"
        val targets = mapOf(
            "arm64-v8a" to "Xray-android-arm64-v8a.zip",
            "armeabi-v7a" to "Xray-linux-arm32-v7a.zip"
        )
        targets.forEach { (abi, zipName) ->
            val dest = File(xrayOut, "$abi/libxray.so")
            if (dest.exists() && dest.length() > 1_000_000) return@forEach
            dest.parentFile.mkdirs()
            try {
                val conn = java.net.URL("$base/$zipName").openConnection() as java.net.HttpURLConnection
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 30000
                conn.readTimeout = 120000
                var found = false
                java.util.zip.ZipInputStream(conn.inputStream).use { zin ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        if (e.name == "xray") {
                            dest.outputStream().use { zin.copyTo(it) }
                            found = true
                            break
                        }
                    }
                }
                if (!found) throw GradleException("xray binary not found inside $zipName")
            } catch (ex: Exception) {
                dest.delete()
                throw GradleException("Could not download Xray core ($zipName): ${ex.message}")
            }
        }
    }
}
tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("JniLibFolders")) dependsOn(downloadXray)
}

android {
    namespace = "com.example.ytsave"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.verse.downloader"
        minSdk = 29
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        // فقط فارسی و انگلیسی؛ ترجمه‌های اضافه‌ی کتابخانه‌ها از APK حذف می‌شود
        resourceConfigurations += listOf("en", "fa")
    }

    sourceSets.getByName("main").jniLibs.srcDir(xrayOut)

    buildFeatures { viewBinding = true }

    packaging { jniLibs { useLegacyPackaging = true } }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
