package com.example.ytsave

import android.content.Context
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.net.URLDecoder

/**
 * اجرای هسته‌ی Xray داخل خود اپ (فایل libxray.so در زمان بیلد اضافه می‌شود).
 * کاربر لینک کانفیگ (vless / vmess / trojan / ss) یا JSON کامل را می‌دهد،
 * ما یک SOCKS محلی روی 127.0.0.1:10808 بالا می‌آوریم و yt-dlp از آن رد می‌شود.
 */
object Xray {
    const val PORT = 10808
    const val PROXY_URL = "socks5h://127.0.0.1:$PORT"

    private var proc: Process? = null
    private var runningFor: String? = null
    private val logTail = ArrayDeque<String>()

    private val plainSchemes = listOf("socks5://", "socks5h://", "socks4://", "socks4a://", "http://", "https://")

    fun isPlain(raw: String) = plainSchemes.any { raw.startsWith(it, true) }

    @Synchronized
    fun isAlive(): Boolean = proc?.isAlive == true

    /** آدرس پراکسی نهایی برای yt-dlp (یا null اگر پراکسی نداریم) */
    fun effectiveProxy(ctx: Context, raw: String): String? {
        val r = raw.trim()
        if (r.isEmpty()) return null
        if (isPlain(r)) return r
        if (!isAlive() || runningFor != r) {
            if (configure(ctx, r) != null) return null
        }
        return PROXY_URL
    }

    /** پراکسی برای HttpURLConnection (مثلاً درخواست AudD) */
    fun javaProxy(ctx: Context, raw: String): Proxy? {
        val p = effectiveProxy(ctx, raw) ?: return null
        val u = Uri.parse(p)
        val host = u.host ?: return null
        val port = if (u.port > 0) u.port else 1080
        val type = if (p.startsWith("http", true)) Proxy.Type.HTTP else Proxy.Type.SOCKS
        return Proxy(type, InetSocketAddress(host, port))
    }

    /**
     * تنظیم و (در صورت نیاز) روشن‌کردن پراکسی. روی ترد پس‌زمینه صدا بزنید.
     * خروجی: null یعنی موفق، در غیر این صورت متن خطا.
     */
    @Synchronized
    fun configure(ctx: Context, raw: String): String? {
        val r = raw.trim()
        stop()
        if (r.isEmpty() || isPlain(r)) return null
        return try {
            val outbound = if (r.startsWith("{")) null else buildOutbound(r)
            val cfg = buildConfig(r, outbound)
            val bin = File(ctx.applicationInfo.nativeLibraryDir, "libxray.so")
            if (!bin.exists()) return "Xray core is missing in this build (libxray.so)."
            val cfgFile = File(ctx.filesDir, "xray.json").apply { writeText(cfg.toString()) }
            logTail.clear()
            val pb = ProcessBuilder(bin.absolutePath, "run", "-c", cfgFile.absolutePath)
                .directory(ctx.filesDir)
                .redirectErrorStream(true)
            pb.environment()["XRAY_LOCATION_ASSET"] = ctx.filesDir.absolutePath
            val p = pb.start()
            proc = p
            Thread {
                try {
                    p.inputStream.bufferedReader().forEachLine { l ->
                        synchronized(logTail) { logTail.addLast(l); while (logTail.size > 15) logTail.removeFirst() }
                    }
                } catch (_: Exception) {}
            }.apply { isDaemon = true; start() }

            val deadline = System.currentTimeMillis() + 6000
            while (System.currentTimeMillis() < deadline) {
                if (!p.isAlive) {
                    proc = null
                    return "Xray stopped: " + tail()
                }
                try {
                    Socket().use { it.connect(InetSocketAddress("127.0.0.1", PORT), 200) }
                    runningFor = r
                    return null
                } catch (_: Exception) { Thread.sleep(150) }
            }
            stop()
            "Xray did not start in time. " + tail()
        } catch (e: Exception) {
            stop()
            e.message ?: e.toString()
        }
    }

    @Synchronized
    fun stop() {
        try { proc?.destroy() } catch (_: Exception) {}
        proc = null
        runningFor = null
    }

    private fun tail(): String = synchronized(logTail) { logTail.takeLast(4).joinToString(" | ").take(300) }

    // ---------------- ساخت کانفیگ ----------------

    private fun buildConfig(raw: String, outbound: JSONObject?): JSONObject {
        val inbound = JSONObject()
            .put("tag", "socks-in").put("listen", "127.0.0.1").put("port", PORT).put("protocol", "socks")
            .put("settings", JSONObject().put("udp", false).put("auth", "noauth"))
        if (outbound == null) { // JSON کامل از کاربر؛ فقط ورودی را جایگزین می‌کنیم
            val j = JSONObject(raw)
            j.put("inbounds", JSONArray().put(inbound))
            if (!j.has("log")) j.put("log", JSONObject().put("loglevel", "warning"))
            return j
        }
        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("inbounds", JSONArray().put(inbound))
            .put("outbounds", JSONArray().put(outbound).put(JSONObject().put("protocol", "freedom").put("tag", "direct")))
    }

    private fun buildOutbound(link: String): JSONObject {
        val l = link.trim()
        return when {
            l.startsWith("vless://", true) -> vless(l)
            l.startsWith("vmess://", true) -> vmess(l)
            l.startsWith("trojan://", true) -> trojan(l)
            l.startsWith("ss://", true) -> shadowsocks(l)
            else -> throw IllegalArgumentException("Unsupported config. Use vless://, vmess://, trojan://, ss:// or a full JSON config.")
        }
    }

    /** دامنه‌ی سرور را با DNS خود اندروید به IP تبدیل می‌کنیم (هسته‌ی Go در اندروید resolver ندارد) */
    private fun resolve(host: String): String {
        if (host.matches(Regex("^[0-9.]+$")) || host.contains(":")) return host
        return InetAddress.getByName(host).hostAddress ?: host
    }

    private fun q(u: Uri, k: String): String? = u.getQueryParameter(k)?.takeIf { it.isNotBlank() }

    private fun stream(
        network: String, security: String, host: String,
        sni: String?, fp: String?, alpn: String?, insecure: Boolean,
        path: String?, hostHeader: String?, serviceName: String?,
        pbk: String?, sid: String?, spx: String?, mode: String?
    ): JSONObject {
        val net = when (network) { "h2" -> "http"; "" -> "tcp"; else -> network }
        val s = JSONObject().put("network", net)
        when (security) {
            "tls" -> s.put("security", "tls").put("tlsSettings", JSONObject().apply {
                put("serverName", sni ?: hostHeader ?: host)
                put("fingerprint", fp ?: "chrome")
                if (!alpn.isNullOrBlank()) put("alpn", JSONArray(alpn.split(",").map { it.trim() }))
                if (insecure) put("allowInsecure", true)
            })
            "reality" -> s.put("security", "reality").put("realitySettings", JSONObject().apply {
                put("serverName", sni ?: host)
                put("fingerprint", fp ?: "chrome")
                put("publicKey", pbk ?: "")
                put("shortId", sid ?: "")
                put("spiderX", spx ?: "")
            })
            else -> s.put("security", "none")
        }
        when (net) {
            "ws" -> s.put("wsSettings", JSONObject().put("path", path ?: "/")
                .put("headers", JSONObject().put("Host", hostHeader ?: sni ?: host)))
            "grpc" -> s.put("grpcSettings", JSONObject().put("serviceName", serviceName ?: path ?: ""))
            "httpupgrade" -> s.put("httpupgradeSettings", JSONObject().put("path", path ?: "/").put("host", hostHeader ?: sni ?: host))
            "xhttp", "splithttp" -> s.put("xhttpSettings", JSONObject().put("path", path ?: "/")
                .put("host", hostHeader ?: sni ?: host).apply { if (mode != null) put("mode", mode) })
            "http" -> s.put("httpSettings", JSONObject().put("path", path ?: "/")
                .put("host", JSONArray().put(hostHeader ?: sni ?: host)))
        }
        return s
    }

    private fun vless(link: String): JSONObject {
        val u = Uri.parse(link)
        val host = u.host ?: throw IllegalArgumentException("Invalid vless link")
        val port = if (u.port > 0) u.port else 443
        val user = JSONObject().put("id", u.userInfo ?: "").put("encryption", q(u, "encryption") ?: "none")
        q(u, "flow")?.let { user.put("flow", it) }
        return JSONObject().put("tag", "proxy").put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(
                JSONObject().put("address", resolve(host)).put("port", port).put("users", JSONArray().put(user)))))
            .put("streamSettings", stream(
                q(u, "type") ?: "tcp", q(u, "security") ?: "none", host,
                q(u, "sni") ?: q(u, "peer"), q(u, "fp"), q(u, "alpn"),
                q(u, "allowInsecure") == "1" || q(u, "insecure") == "1",
                q(u, "path"), q(u, "host"), q(u, "serviceName"),
                q(u, "pbk"), q(u, "sid"), q(u, "spx"), q(u, "mode")))
    }

    private fun b64(s: String): String {
        val t = s.trim().replace('-', '+').replace('_', '/')
        return String(Base64.decode(t, Base64.DEFAULT or Base64.NO_WRAP))
    }

    private fun vmess(link: String): JSONObject {
        val j = JSONObject(b64(link.substring(8).substringBefore('#')))
        val host = j.optString("add")
        val port = j.optString("port").toIntOrNull() ?: 443
        val user = JSONObject().put("id", j.optString("id")).put("alterId", j.optString("aid", "0").toIntOrNull() ?: 0)
            .put("security", j.optString("scy").ifBlank { "auto" })
        val net = j.optString("net").ifBlank { "tcp" }
        val path = j.optString("path").takeIf { it.isNotBlank() }
        return JSONObject().put("tag", "proxy").put("protocol", "vmess")
            .put("settings", JSONObject().put("vnext", JSONArray().put(
                JSONObject().put("address", resolve(host)).put("port", port).put("users", JSONArray().put(user)))))
            .put("streamSettings", stream(
                net, if (j.optString("tls") == "tls") "tls" else "none", host,
                j.optString("sni").takeIf { it.isNotBlank() }, j.optString("fp").takeIf { it.isNotBlank() },
                j.optString("alpn").takeIf { it.isNotBlank() }, false,
                path, j.optString("host").takeIf { it.isNotBlank() },
                if (net == "grpc") path else null, null, null, null, null))
    }

    private fun trojan(link: String): JSONObject {
        val u = Uri.parse(link)
        val host = u.host ?: throw IllegalArgumentException("Invalid trojan link")
        val port = if (u.port > 0) u.port else 443
        return JSONObject().put("tag", "proxy").put("protocol", "trojan")
            .put("settings", JSONObject().put("servers", JSONArray().put(
                JSONObject().put("address", resolve(host)).put("port", port)
                    .put("password", URLDecoder.decode(u.userInfo ?: "", "UTF-8")))))
            .put("streamSettings", stream(
                q(u, "type") ?: "tcp", q(u, "security") ?: "tls", host,
                q(u, "sni") ?: q(u, "peer"), q(u, "fp"), q(u, "alpn"),
                q(u, "allowInsecure") == "1", q(u, "path"), q(u, "host"), q(u, "serviceName"),
                q(u, "pbk"), q(u, "sid"), q(u, "spx"), q(u, "mode")))
    }

    private fun shadowsocks(link: String): JSONObject {
        val body = link.substring(5).substringBefore('#').substringBefore('?')
        val method: String; val password: String; val host: String; val port: Int
        if (body.contains('@')) {
            val ui = body.substringBeforeLast('@')
            val hp = body.substringAfterLast('@')
            val cred = if (ui.contains(':')) URLDecoder.decode(ui, "UTF-8") else b64(ui)
            method = cred.substringBefore(':'); password = cred.substringAfter(':')
            host = hp.substringBeforeLast(':'); port = hp.substringAfterLast(':').toInt()
        } else {
            val d = b64(body)
            method = d.substringBefore(':'); val rest = d.substringAfter(':')
            password = rest.substringBeforeLast('@'); val hp = rest.substringAfterLast('@')
            host = hp.substringBeforeLast(':'); port = hp.substringAfterLast(':').toInt()
        }
        return JSONObject().put("tag", "proxy").put("protocol", "shadowsocks")
            .put("settings", JSONObject().put("servers", JSONArray().put(
                JSONObject().put("address", resolve(host)).put("port", port)
                    .put("method", method).put("password", password))))
    }
}
