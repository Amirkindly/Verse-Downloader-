package com.example.ytsave

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.MediaController
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.ytsave.databinding.FragmentDownloaderBinding
import com.google.android.material.button.MaterialButton
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** One full download/preview page; two instances exist: YouTube and Instagram. */
class DownloaderFragment : Fragment() {

    companion object {
        fun newInstance(insta: Boolean) = DownloaderFragment().apply {
            arguments = Bundle().apply { putBoolean("insta", insta) }
        }
    }

    private var _b: FragmentDownloaderBinding? = null
    private val b get() = _b!!
    private var insta = false
    private var pendingLink: String? = null

    private var working = false
    private var checkedUrl: String? = null
    private var songUrl: String? = null
    private var player: MediaPlayer? = null
    private var playingBtn: MaterialButton? = null
    private var audioReq = 0
    private val prefs by lazy { requireContext().getSharedPreferences("ytsave", Context.MODE_PRIVATE) }

    private val cookiePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null && _b != null) {
                try {
                    requireContext().contentResolver.openInputStream(uri)!!.use { i ->
                        File(requireContext().filesDir, "cookies.txt").outputStream().use { i.copyTo(it) }
                    }
                    b.status.setText(R.string.cookie_saved)
                } catch (e: Exception) {
                    b.status.setText(R.string.cookie_error)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        insta = arguments?.getBoolean("insta") ?: false
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _b = FragmentDownloaderBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (insta) {
            b.pageIcon.setImageResource(R.drawable.ic_instagram)
            b.pageTitle.setText(R.string.page_title_ig)
            b.pageSub.setText(R.string.page_sub_ig)
            b.url.hint = "https://www.instagram.com/reel/..."
            b.hint.visibility = View.VISIBLE
            b.hint.setText(R.string.insta_hint)
            b.cookies.visibility = View.VISIBLE
        } else {
            b.pageIcon.setImageResource(R.drawable.ic_youtube)
            b.pageTitle.setText(R.string.page_title_yt)
            b.pageSub.setText(R.string.page_sub_yt)
            b.url.hint = "https://youtu.be/..."
        }
        b.token.setText(prefs.getString("audd", ""))

        val loading = getString(R.string.engine_loading)
        val readyMsg = getString(R.string.engine_ready)
        b.status.text = if (Engine.ready.value) readyMsg else loading
        viewLifecycleOwner.lifecycleScope.launch {
            Engine.ready.collect { if (it && _b != null && b.status.text.toString() == loading) b.status.text = readyMsg }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            Engine.error.collect { e -> if (e != null && _b != null) b.status.text = getString(R.string.engine_error, e) }
        }

        b.url.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                if (s.toString().trim() != checkedUrl) {
                    checkedUrl = null
                    b.preview.stopPlayback()
                    b.preview.visibility = View.GONE
                    b.info.text = ""
                }
                songUrl = null
                b.song.text = ""
                stopAudio()
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, bf: Int, c: Int) {}
        })

        b.paste.setOnClickListener {
            val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
            if (t.isNullOrBlank()) b.status.setText(R.string.clipboard_empty)
            else b.url.setText(Regex("https?://\\S+").find(t)?.value ?: t.trim())
        }
        b.check.setOnClickListener { checkLink() }
        b.playClip.setOnClickListener { checkedUrl?.let { toggleAudio(b.playClip, it) } }
        b.download.setOnClickListener { checkedUrl?.let { startDownload(it, b.audio.isChecked) } }
        b.recognize.setOnClickListener { recognizeSong() }
        b.songListen.setOnClickListener { songUrl?.let { toggleAudio(b.songListen, it) } }
        b.songDownload.setOnClickListener { songUrl?.let { startDownload(it, true) } }
        b.cookies.setOnClickListener { cookiePicker.launch(arrayOf("*/*")) }
        b.update.setOnClickListener { updateEngine() }
        b.proxy.setOnClickListener { showProxyDialog() }
        refreshEnabled()

        pendingLink?.let { b.url.setText(it); pendingLink = null }
    }

    /** از MainActivity برای لینک‌های Share شده */
    fun setLink(link: String) {
        if (_b != null) b.url.setText(link) else pendingLink = link
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (_b == null) return
        if (hidden) {
            stopAudio()
            b.preview.pause()
        } else {
            val t = prefs.getString("audd", "") ?: ""
            if (b.token.text.toString() != t) b.token.setText(t)
        }
    }

    override fun onDestroyView() {
        player?.release()
        player = null
        _b?.preview?.stopPlayback()
        _b = null
        super.onDestroyView()
    }

    private fun ui(block: () -> Unit) {
        activity?.runOnUiThread { if (_b != null) block() }
    }

    private fun refreshEnabled() {
        if (_b == null) return
        b.check.isEnabled = !working
        b.paste.isEnabled = !working
        b.update.isEnabled = !working
        b.proxy.isEnabled = !working
        b.recognize.isEnabled = !working
        b.cookies.isEnabled = !working
        b.download.isEnabled = !working && checkedUrl != null
        b.playClip.isEnabled = !working && checkedUrl != null
        b.songDownload.isEnabled = !working && songUrl != null
        b.songListen.isEnabled = !working && songUrl != null
    }

    private fun busy(on: Boolean, msg: String? = null) {
        if (_b == null) return
        working = on
        refreshEnabled()
        msg?.let { b.status.text = it }
    }

    private fun YoutubeDLRequest.common(): YoutubeDLRequest {
        addOption("--no-playlist")
        addOption("--retries", "5")
        addOption("--socket-timeout", "20")
        val px = Xray.effectiveProxy(requireContext().applicationContext, prefs.getString("proxy", "").orEmpty())
        if (px != null) addOption("--proxy", px)
        val c = File(requireContext().filesDir, "cookies.txt")
        if (c.exists()) addOption("--cookies", c.absolutePath)
        return this
    }

    private fun fmt(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)

    private fun validHost(u: String): Boolean {
        val h = Uri.parse(u).host?.lowercase() ?: return false
        return if (insta) h.endsWith("instagram.com") || h == "instagr.am"
        else h.endsWith("youtube.com") || h == "youtu.be" || h.endsWith("youtube-nocookie.com")
    }

    private fun directUrl(url: String, format: String): String {
        val req = YoutubeDLRequest(url).common()
        req.addOption("-f", format)
        req.addOption("-g")
        val out = YoutubeDL.getInstance().execute(req, null, null).out
        return out.lines().map { it.trim() }.first { it.startsWith("http") }
    }

    // ---------- بررسی و پیش‌نمایش ----------

    private fun checkLink() {
        val url = b.url.text.toString().trim()
        if (!Engine.ready.value) { b.status.setText(R.string.engine_wait); return }
        if (!url.startsWith("http")) { b.status.setText(R.string.invalid_link); return }
        if (!validHost(url)) {
            b.status.setText(if (insta) R.string.not_insta_link else R.string.not_yt_link)
            return
        }
        viewLifecycleOwner.lifecycleScope.launch {
            busy(true, getString(R.string.checking_link))
            b.info.text = ""
            try {
                val info = withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().getInfo(YoutubeDLRequest(url).common())
                }
                if (_b == null) return@launch
                checkedUrl = url
                b.info.text = getString(R.string.info_fmt, info.title ?: "-", info.uploader ?: "-", fmt(info.duration.toInt()))
                busy(false, getString(R.string.link_ok))
                loadPreview(url)
            } catch (e: Exception) {
                busy(
                    false,
                    getString(R.string.link_bad, e.message?.take(300) ?: "") +
                        if (insta) getString(R.string.link_bad_insta_extra) else ""
                )
            }
        }
    }

    private fun loadPreview(url: String) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val u = withContext(Dispatchers.IO) { directUrl(url, "b[ext=mp4]/b") }
                if (_b == null || checkedUrl != url) return@launch
                val mc = MediaController(requireContext())
                mc.setAnchorView(b.preview)
                b.preview.setMediaController(mc)
                b.preview.setOnErrorListener { _, _, _ ->
                    b.preview.visibility = View.GONE
                    b.status.setText(R.string.preview_failed)
                    true
                }
                b.preview.visibility = View.VISIBLE
                b.preview.setVideoURI(Uri.parse(u))
                b.preview.seekTo(100)
            } catch (e: Exception) {
                _b?.preview?.visibility = View.GONE
            }
        }
    }

    // ---------- پخش صدا (کلیپ یا آهنگ) ----------

    private fun stopAudio() {
        audioReq++
        player?.let {
            try { it.stop() } catch (_: Exception) { }
            it.release()
        }
        player = null
        playingBtn = null
        if (_b == null) return
        idle(b.playClip, R.string.btn_listen_clip)
        idle(b.songListen, R.string.btn_listen_song)
        refreshEnabled()
    }

    private fun idle(btn: MaterialButton, textRes: Int) {
        btn.setText(textRes)
        btn.setIconResource(R.drawable.ic_play)
    }

    private fun toggleAudio(btn: MaterialButton, source: String) {
        if (playingBtn == btn) { stopAudio(); return }
        stopAudio()
        val my = audioReq
        playingBtn = btn
        btn.setText(R.string.btn_loading)
        btn.isEnabled = false
        b.preview.pause()
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val u = withContext(Dispatchers.IO) { directUrl(source, "ba/b") }
                if (_b == null || my != audioReq) return@launch
                val mp = MediaPlayer()
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                mp.setDataSource(u)
                mp.setOnPreparedListener {
                    if (_b != null && my == audioReq) {
                        it.start()
                        btn.setText(R.string.btn_stop)
                        btn.setIconResource(R.drawable.ic_stop)
                        btn.isEnabled = true
                    }
                }
                mp.setOnCompletionListener { stopAudio() }
                mp.setOnErrorListener { _, _, _ ->
                    stopAudio()
                    _b?.status?.setText(R.string.audio_failed)
                    true
                }
                player = mp
                mp.prepareAsync()
            } catch (e: Exception) {
                stopAudio()
                _b?.status?.text = getString(R.string.audio_error, e.message?.take(200) ?: "")
            }
        }
    }

    // ---------- دانلود ----------

    private fun startDownload(url: String, audio: Boolean) {
        stopAudio()
        b.preview.pause()
        val ctx = requireContext().applicationContext
        val storageFail = getString(R.string.storage_failed)
        viewLifecycleOwner.lifecycleScope.launch {
            busy(true, getString(R.string.downloading))
            b.progress.progress = 0
            try {
                val saved = withContext(Dispatchers.IO) {
                    val tmp = File(ctx.cacheDir, "dl_${if (insta) "ig" else "yt"}").apply { deleteRecursively(); mkdirs() }
                    val req = YoutubeDLRequest(url).common()
                    req.addOption("-o", "${tmp.absolutePath}/%(title).80s.%(ext)s")
                    if (audio) {
                        req.addOption("-x")
                        req.addOption("--audio-format", "mp3")
                        req.addOption("--audio-quality", "0")
                    } else {
                        req.addOption("-f", "bv*[height<=720]+ba/b[height<=720]/b")
                        req.addOption("--merge-output-format", "mp4")
                    }
                    YoutubeDL.getInstance().execute(req, null) { p, _, _ ->
                        ui { b.progress.progress = p.toInt().coerceIn(0, 100) }
                    }
                    val out = tmp.listFiles()?.filter {
                        it.isFile && (it.extension == "mp3" || it.extension == "mp4")
                    } ?: emptyList()
                    val names = out.map { saveToMediaStore(ctx, it, it.extension == "mp3", storageFail) }
                    tmp.deleteRecursively()
                    names
                }
                if (_b == null) return@launch
                b.progress.progress = 100
                busy(
                    false,
                    if (saved.isEmpty()) getString(R.string.no_file)
                    else getString(R.string.saved_fmt, saved.joinToString("\n"), if (audio) "Music" else "Movies")
                )
            } catch (e: Exception) {
                busy(false, getString(R.string.download_error, e.message?.take(300) ?: ""))
            }
        }
    }

    private fun saveToMediaStore(ctx: Context, file: File, audio: Boolean, failMsg: String): String {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, if (audio) "audio/mpeg" else "video/mp4")
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                (if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/YTSave"
            )
        }
        val collection = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = ctx.contentResolver.insert(collection, values) ?: throw Exception(failMsg)
        ctx.contentResolver.openOutputStream(uri)!!.use { os -> file.inputStream().use { it.copyTo(os) } }
        return file.name
    }

    // ---------- تشخیص آهنگ ----------

    private data class Found(val artist: String, val title: String, val ytUrl: String?, val ytInfo: String?)

    private fun recognizeSong() {
        val url = b.url.text.toString().trim()
        val token = b.token.text.toString().trim()
        if (!Engine.ready.value) { b.status.setText(R.string.engine_wait_short); return }
        if (!url.startsWith("http") || !validHost(url)) { b.status.setText(R.string.need_link_first); return }
        if (token.isEmpty()) { b.status.setText(R.string.need_token); return }
        prefs.edit().putString("audd", token).apply()
        stopAudio()
        val ctx = requireContext().applicationContext
        val stepRecognize = getString(R.string.step_recognize)
        val stepFind = getString(R.string.step_find)
        val sampleFailed = getString(R.string.sample_failed)

        viewLifecycleOwner.lifecycleScope.launch {
            songUrl = null
            b.song.text = ""
            busy(true, getString(R.string.step_extract))
            try {
                val found = withContext(Dispatchers.IO) {
                    val dir = File(ctx.cacheDir, "rec_${if (insta) "ig" else "yt"}").apply { deleteRecursively(); mkdirs() }
                    val req = YoutubeDLRequest(url).common()
                    req.addOption("-o", "${dir.absolutePath}/sample.%(ext)s")
                    req.addOption("-x")
                    req.addOption("--audio-format", "mp3")
                    req.addOption("--audio-quality", "5")
                    req.addOption("--download-sections", "*0-30")
                    YoutubeDL.getInstance().execute(req, null) { _, _, _ -> }
                    val f = File(dir, "sample.mp3")
                    if (!f.exists()) throw Exception(sampleFailed)

                    ui { b.status.text = stepRecognize }
                    val rec = audd(f, token)
                    dir.deleteRecursively()
                    if (rec == null) return@withContext null

                    ui { b.status.text = stepFind }
                    var ytUrl: String? = null
                    var ytInfo: String? = null
                    try {
                        val sreq = YoutubeDLRequest("ytsearch1:${rec.first} ${rec.second}")
                        sreq.addOption("--print", "%(webpage_url)s\t%(title)s\t%(duration_string)s")
                        val line = YoutubeDL.getInstance().execute(sreq, null, null)
                            .out.trim().lines().lastOrNull { it.contains("http") }
                        if (line != null) {
                            val p = line.split("\t")
                            ytUrl = p[0]
                            ytInfo = p.drop(1).joinToString(" — ")
                        }
                    } catch (_: Exception) { }
                    Found(rec.first, rec.second, ytUrl, ytInfo)
                }
                if (_b == null) return@launch
                if (found == null) {
                    busy(false, getString(R.string.not_recognized))
                } else {
                    songUrl = found.ytUrl
                    b.song.text = getString(R.string.song_fmt, found.title, found.artist) +
                        (found.ytInfo?.let { getString(R.string.song_yt_result, it) } ?: getString(R.string.song_file_missing))
                    busy(false, getString(if (found.ytUrl != null) R.string.song_listen_hint else R.string.song_name_only))
                }
            } catch (e: Exception) {
                busy(false, getString(R.string.recognize_error, e.message?.take(300) ?: ""))
            }
        }
    }

    private fun audd(file: File, token: String): Pair<String, String>? {
        val boundary = "----ytsave${System.currentTimeMillis()}"
        val auddUrl = URL("https://api.audd.io/")
        val jp = Xray.javaProxy(requireContext().applicationContext, prefs.getString("proxy", "").orEmpty())
        val conn = (if (jp != null) auddUrl.openConnection(jp) else auddUrl.openConnection()) as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        conn.outputStream.use { os ->
            os.write("--$boundary\r\nContent-Disposition: form-data; name=\"api_token\"\r\n\r\n$token\r\n".toByteArray())
            os.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"clip.mp3\"\r\nContent-Type: audio/mpeg\r\n\r\n".toByteArray())
            file.inputStream().use { it.copyTo(os) }
            os.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().readText()
        val j = JSONObject(text)
        if (j.optString("status") != "success") {
            throw Exception(j.optJSONObject("error")?.optString("error_message") ?: text.take(200))
        }
        val r = j.optJSONObject("result") ?: return null
        return r.optString("artist") to r.optString("title")
    }

    private fun showProxyDialog() {
        val input = EditText(requireContext()).apply {
            setText(prefs.getString("proxy", ""))
            hint = getString(R.string.proxy_hint)
            minLines = 3
            maxLines = 6
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.proxy_title)
            .setMessage(R.string.proxy_msg)
            .setView(input)
            .setPositiveButton(R.string.proxy_save) { _, _ ->
                val v = input.text.toString().trim()
                prefs.edit().putString("proxy", v).apply()
                val ctx = requireContext().applicationContext
                viewLifecycleOwner.lifecycleScope.launch {
                    if (v.isEmpty()) {
                        withContext(Dispatchers.IO) { Xray.stop() }
                        b.status.setText(R.string.proxy_cleared)
                        return@launch
                    }
                    busy(true, getString(R.string.proxy_connecting))
                    val err = withContext(Dispatchers.IO) { Xray.configure(ctx, v) }
                    busy(false, if (err == null) getString(R.string.proxy_saved) else getString(R.string.proxy_error, err))
                }
            }
            .setNeutralButton(R.string.proxy_paste) { _, _ ->
                val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()?.trim()
                if (!t.isNullOrEmpty()) {
                    prefs.edit().putString("proxy", t).apply()
                    showProxyDialog()
                }
            }
            .setNegativeButton(R.string.proxy_cancel, null)
            .show()
    }

    private fun updateEngine() {
        if (!Engine.ready.value) return
        val ctx = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            busy(true, getString(R.string.update_progress))
            try {
                val st = withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.STABLE)
                }
                busy(false, getString(R.string.update_done, st.toString()))
            } catch (e: Exception) {
                busy(false, getString(R.string.update_error, e.message?.take(200) ?: ""))
            }
        }
    }
}
