package com.example.ytsave

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/** تغییر زبان برنامه (فارسی/انگلیسی). زبان انتخابی ذخیره می‌شود و Activity خودکار دوباره ساخته می‌شود. */
object LocaleHelper {

    fun isPersian(ctx: Context): Boolean {
        val app = AppCompatDelegate.getApplicationLocales()
        val lang = if (!app.isEmpty) app[0]?.language
        else ctx.resources.configuration.locales[0].language
        return lang == "fa"
    }

    fun toggle(ctx: Context) {
        val next = if (isPersian(ctx)) "en" else "fa"
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(next))
    }
}
