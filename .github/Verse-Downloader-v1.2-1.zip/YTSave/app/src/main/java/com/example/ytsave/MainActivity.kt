package com.example.ytsave

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.ytsave.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var yt: DownloaderFragment
    private lateinit var ig: DownloaderFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        val fm = supportFragmentManager
        var y = fm.findFragmentByTag("yt") as? DownloaderFragment
        var i = fm.findFragmentByTag("ig") as? DownloaderFragment
        if (y == null || i == null) {
            y = DownloaderFragment.newInstance(false)
            i = DownloaderFragment.newInstance(true)
            fm.beginTransaction()
                .add(R.id.container, y, "yt")
                .add(R.id.container, i, "ig")
                .hide(i)
                .commitNow()
        }
        yt = y
        ig = i

        b.nav.setOnItemSelectedListener { item ->
            show(item.itemId == R.id.nav_instagram)
            true
        }
        b.langBtn.setOnClickListener { LocaleHelper.toggle(this) }
        b.profileBtn.setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java)) }
        b.infoBtn.setOnClickListener { startActivity(Intent(this, AboutActivity::class.java)) }

        handleShare(intent)
    }

    override fun onResume() {
        super.onResume()
        val s = Accounts.settings(this)
        if (!Accounts.validateSession(this) && !s.allow) {
            startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            finish()
            return
        }
        b.announce.text = s.announce
        b.announce.visibility = if (s.announce.isBlank()) View.GONE else View.VISIBLE
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    private fun show(insta: Boolean) {
        supportFragmentManager.beginTransaction()
            .show(if (insta) ig else yt)
            .hide(if (insta) yt else ig)
            .commit()
    }

    /** لینکی که از اپ یوتیوب/اینستاگرام Share شده به تب درست می‌رود */
    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val link = Regex("https?://\\S+").find(text)?.value ?: return
        val insta = link.contains("instagram.com") || link.contains("instagr.am")
        b.nav.selectedItemId = if (insta) R.id.nav_instagram else R.id.nav_youtube
        (if (insta) ig else yt).setLink(link)
    }
}
