package com.example.ytsave

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ytsave.databinding.ActivityAdminBinding
import com.google.android.material.button.MaterialButton

class AdminActivity : AppCompatActivity() {
    private lateinit var b: ActivityAdminBinding
    private var gHeight = 480

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Accounts.isAdmin(this)) { finish(); return }
        b = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.back.setOnClickListener { finish() }

        b.create.setOnClickListener {
            val ok = Accounts.createUser(this, b.newUser.text.toString(), b.newPass.text.toString())
            Toast.makeText(this, if (ok) R.string.user_created else R.string.user_bad, Toast.LENGTH_LONG).show()
            if (ok) { b.newUser.setText(""); b.newPass.setText(""); renderUsers() }
        }

        val s = Accounts.settings(this)
        b.swGuest.isChecked = s.allow
        b.gLimit.setText(s.limit.toString())
        b.gRate.setText(s.rate.toString())
        b.announce.setText(s.announce)
        gHeight = s.height
        refreshQuality()
        b.gQuality.setOnClickListener { Accounts.pickQuality(this, gHeight) { gHeight = it; refreshQuality() } }
        b.saveGuest.setOnClickListener {
            Accounts.saveSettings(
                this, GuestSettings(
                    b.swGuest.isChecked,
                    b.gLimit.text.toString().trim().toIntOrNull()?.coerceAtLeast(0) ?: 0,
                    gHeight,
                    b.gRate.text.toString().trim().toIntOrNull()?.coerceAtLeast(0) ?: 0,
                    b.announce.text.toString().trim()
                )
            )
            Toast.makeText(this, R.string.saved_ok, Toast.LENGTH_SHORT).show()
        }
        b.resetGuest.setOnClickListener {
            Accounts.resetGuest(this)
            Toast.makeText(this, R.string.guest_reset_done, Toast.LENGTH_SHORT).show()
        }
        renderUsers()
    }

    private fun refreshQuality() {
        b.gQuality.text = getString(R.string.btn_guest_quality, Accounts.qualityLabel(this, gHeight))
    }

    private fun renderUsers() {
        val list = Accounts.listUsers(this)
        b.stats.text = getString(R.string.admin_stats, list.size, Accounts.totalDownloads(this))
        b.usersList.removeAllViews()
        if (list.isEmpty()) {
            b.usersList.addView(TextView(this).apply { setText(R.string.users_empty) })
            return
        }
        list.forEach { u ->
            b.usersList.addView(TextView(this).apply {
                text = getString(
                    R.string.user_row, u.name, u.downloads,
                    getString(if (u.active) R.string.state_active else R.string.state_disabled) + " • " + Accounts.fmtDate(u.created)
                )
                textSize = 15f
                setPadding(0, 16, 0, 0)
                textDirection = View.TEXT_DIRECTION_LTR
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun btn(t: Int, click: () -> Unit) = MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                setText(t); isAllCaps = false; minWidth = 0; setOnClickListener { click() }
            }
            row.addView(btn(if (u.active) R.string.btn_disable else R.string.btn_enable) {
                Accounts.setActive(this, u.name, !u.active); renderUsers()
            })
            row.addView(btn(R.string.btn_reset_pw) { resetDialog(u.name) })
            row.addView(btn(R.string.btn_delete) {
                AlertDialog.Builder(this)
                    .setMessage(getString(R.string.confirm_delete, u.name))
                    .setPositiveButton(R.string.yes) { _, _ -> Accounts.deleteUser(this, u.name); renderUsers() }
                    .setNegativeButton(R.string.proxy_cancel, null).show()
            })
            b.usersList.addView(row)
        }
    }

    private fun resetDialog(name: String) {
        val et = EditText(this).apply {
            setHint(R.string.hint_new_pw)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.reset_pw_title, name))
            .setView(et)
            .setPositiveButton(R.string.btn_save) { _, _ ->
                val ok = Accounts.resetPassword(this, name, et.text.toString())
                Toast.makeText(this, if (ok) R.string.pw_changed else R.string.pw_short, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.proxy_cancel, null).show()
    }
}
