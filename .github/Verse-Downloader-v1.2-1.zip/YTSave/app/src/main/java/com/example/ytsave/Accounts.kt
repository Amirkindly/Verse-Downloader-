package com.example.ytsave

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import androidx.appcompat.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class UserRec(val name: String, val active: Boolean, val downloads: Int, val created: Long)
data class GuestSettings(val allow: Boolean, val limit: Int, val height: Int, val rate: Int, val announce: String)

/**
 * حساب‌ها و تنظیمات؛ همه‌چیز فقط روی همین دستگاه (SharedPreferences) ذخیره می‌شود.
 * رمزها هرگز به‌صورت متن ساده ذخیره نمی‌شوند (PBKDF2 + salt).
 */
object Accounts {
    const val ADMIN_USER = "amir#2000"
    private const val ADMIN_SALT = "verse-admin-salt-v1"
    private const val ADMIN_HASH = "fe936cf0ef6e76db516ead403e9377696341cd5d8222f0a0c66513802fd086d4"

    enum class LoginResult { OK, BAD, DISABLED }

    val QUALITIES = intArrayOf(0, 360, 480, 720, 1080)

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("verse_auth", Context.MODE_PRIVATE)

    // ---------- رمز ----------

    private fun hash(pw: String, salt: String): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt.toByteArray(), 10000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun newSalt(): String {
        val b = ByteArray(16); SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    private fun same(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    private fun users(ctx: Context): JSONObject = try { JSONObject(sp(ctx).getString("users", "{}")!!) } catch (_: Exception) { JSONObject() }
    private fun saveUsers(ctx: Context, u: JSONObject) { sp(ctx).edit().putString("users", u.toString()).apply() }

    private fun verify(ctx: Context, name: String, pw: String): LoginResult {
        val n = name.trim().lowercase()
        if (n == ADMIN_USER) {
            val s = sp(ctx)
            val salt = s.getString("admin_salt", null) ?: ADMIN_SALT
            val h = s.getString("admin_hash", null) ?: ADMIN_HASH
            return if (same(hash(pw, salt), h)) LoginResult.OK else LoginResult.BAD
        }
        val u = users(ctx).optJSONObject(n) ?: return LoginResult.BAD
        if (!same(hash(pw, u.optString("salt")), u.optString("hash"))) return LoginResult.BAD
        return if (u.optBoolean("active", true)) LoginResult.OK else LoginResult.DISABLED
    }

    // ---------- نشست ----------

    fun login(ctx: Context, name: String, pw: String): LoginResult {
        val r = verify(ctx, name, pw)
        if (r == LoginResult.OK) sp(ctx).edit().putString("session", name.trim().lowercase()).apply()
        return r
    }

    fun logout(ctx: Context) { sp(ctx).edit().remove("session").apply() }

    /** نام کاربر فعلی؛ رشته‌ی خالی یعنی مهمان */
    fun current(ctx: Context): String = sp(ctx).getString("session", "") ?: ""

    fun isAdmin(ctx: Context) = current(ctx) == ADMIN_USER

    /** اگر حساب حذف یا غیرفعال شده، نشست پاک می‌شود. خروجی: آیا کاربر هنوز واردشده است؟ */
    fun validateSession(ctx: Context): Boolean {
        val c = current(ctx)
        if (c.isEmpty()) return false
        if (c == ADMIN_USER) return true
        val u = users(ctx).optJSONObject(c)
        if (u == null || !u.optBoolean("active", true)) { logout(ctx); return false }
        return true
    }

    fun roleLabel(ctx: Context): String = ctx.getString(
        when { isAdmin(ctx) -> R.string.role_admin; current(ctx).isEmpty() -> R.string.role_guest; else -> R.string.role_user }
    )

    // ---------- مدیریت حساب‌ها (ادمین) ----------

    fun listUsers(ctx: Context): List<UserRec> {
        val u = users(ctx)
        return u.keys().asSequence().map {
            val o = u.getJSONObject(it)
            UserRec(it, o.optBoolean("active", true), o.optInt("dl", 0), o.optLong("created", 0))
        }.sortedBy { it.name }.toList()
    }

    fun totalDownloads(ctx: Context) = listUsers(ctx).sumOf { it.downloads } + sp(ctx).getInt("admin_dl", 0)

    /** خروجی: true اگر ساخته شد */
    fun createUser(ctx: Context, name: String, pw: String): Boolean {
        val n = name.trim().lowercase()
        if (!Regex("^[a-z0-9_.-]{3,24}$").matches(n) || pw.length < 4) return false
        val u = users(ctx)
        if (n == ADMIN_USER || u.has(n)) return false
        val salt = newSalt()
        u.put(n, JSONObject().put("salt", salt).put("hash", hash(pw, salt)).put("active", true).put("dl", 0).put("created", System.currentTimeMillis()))
        saveUsers(ctx, u)
        return true
    }

    fun setActive(ctx: Context, name: String, on: Boolean) {
        val u = users(ctx); u.optJSONObject(name)?.put("active", on); saveUsers(ctx, u)
    }

    fun deleteUser(ctx: Context, name: String) {
        val u = users(ctx); u.remove(name); saveUsers(ctx, u)
        ctx.applicationContext.getSharedPreferences("verse_u_${name.hashCode()}", Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun resetPassword(ctx: Context, name: String, pw: String): Boolean {
        if (pw.length < 4) return false
        val u = users(ctx); val o = u.optJSONObject(name) ?: return false
        val salt = newSalt(); o.put("salt", salt).put("hash", hash(pw, salt)); saveUsers(ctx, u)
        return true
    }

    /** تغییر رمز خود کاربر (ادمین هم می‌تواند رمز خودش را عوض کند) */
    fun changePassword(ctx: Context, old: String, new: String): Int? {
        val me = current(ctx)
        if (verify(ctx, me, old) != LoginResult.OK) return R.string.pw_wrong
        if (new.length < 4) return R.string.pw_short
        val salt = newSalt()
        if (me == ADMIN_USER) sp(ctx).edit().putString("admin_salt", salt).putString("admin_hash", hash(new, salt)).apply()
        else resetPassword(ctx, me, new)
        return null
    }

    // ---------- تنظیمات مهمان / اعلان (ادمین) ----------

    fun settings(ctx: Context): GuestSettings {
        val s = sp(ctx)
        return GuestSettings(
            s.getBoolean("allow_guest", true), s.getInt("guest_limit", 3), s.getInt("guest_height", 480),
            s.getInt("guest_rate", 0), s.getString("announce", "") ?: ""
        )
    }

    fun saveSettings(ctx: Context, g: GuestSettings) {
        sp(ctx).edit().putBoolean("allow_guest", g.allow).putInt("guest_limit", g.limit)
            .putInt("guest_height", g.height).putInt("guest_rate", g.rate).putString("announce", g.announce).apply()
    }

    // ---------- شمارنده‌ی مهمان ----------

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun guestUsed(ctx: Context): Int {
        val s = sp(ctx)
        return if (s.getString("g_day", "") == today()) s.getInt("g_cnt", 0) else 0
    }

    fun resetGuest(ctx: Context) { sp(ctx).edit().putString("g_day", today()).putInt("g_cnt", 0).apply() }

    // ---------- تنظیمات شخصی هر کاربر ----------

    fun userPrefs(ctx: Context): SharedPreferences {
        val who = current(ctx).ifEmpty { "guest" }
        return ctx.applicationContext.getSharedPreferences("verse_u_${who.hashCode()}", Context.MODE_PRIVATE)
    }

    private fun loggedIn(ctx: Context) = current(ctx).isNotEmpty()

    fun effRate(ctx: Context): Int =
        if (loggedIn(ctx)) userPrefs(ctx).getInt("rate", 0) else settings(ctx).rate

    fun effHeight(ctx: Context): Int =
        if (loggedIn(ctx)) userPrefs(ctx).getInt("height", 720) else settings(ctx).height

    fun fast(ctx: Context) = loggedIn(ctx) && userPrefs(ctx).getBoolean("fast", false)
    fun wifiOnly(ctx: Context) = loggedIn(ctx) && userPrefs(ctx).getBoolean("wifi", false)
    fun defaultMp3(ctx: Context) = loggedIn(ctx) && userPrefs(ctx).getBoolean("mp3", false)

    fun formatSelector(ctx: Context): String {
        val h = effHeight(ctx)
        return if (h <= 0) "bv*+ba/b" else "bv*[height<=$h]+ba/b[height<=$h]/b"
    }

    /** اگر دانلود مجاز نیست، متن خطا (resource id) را می‌دهد */
    fun downloadBlock(ctx: Context): Int? {
        if (!loggedIn(ctx)) {
            val s = settings(ctx)
            if (s.limit > 0 && guestUsed(ctx) >= s.limit) return R.string.err_guest_limit
        }
        if (wifiOnly(ctx)) {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            if (cm.isActiveNetworkMetered) return R.string.err_wifi_only
        }
        return null
    }

    fun recordDownload(ctx: Context, titles: List<String>, audio: Boolean) {
        val me = current(ctx)
        if (me.isEmpty()) {
            val s = sp(ctx)
            s.edit().putString("g_day", today()).putInt("g_cnt", guestUsed(ctx) + titles.size).apply()
            return
        }
        if (me == ADMIN_USER) sp(ctx).edit().putInt("admin_dl", sp(ctx).getInt("admin_dl", 0) + titles.size).apply()
        else {
            val u = users(ctx); val o = u.optJSONObject(me)
            if (o != null) { o.put("dl", o.optInt("dl", 0) + titles.size); saveUsers(ctx, u) }
        }
        val up = userPrefs(ctx)
        val old = try { JSONArray(up.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val arr = JSONArray()
        val now = System.currentTimeMillis()
        titles.forEach { arr.put(JSONObject().put("t", it).put("ts", now).put("a", audio)) }
        for (i in 0 until minOf(old.length(), 50 - titles.size)) arr.put(old.get(i))
        up.edit().putString("history", arr.toString()).apply()
    }

    fun myDownloads(ctx: Context): Int {
        val me = current(ctx)
        return if (me == ADMIN_USER) sp(ctx).getInt("admin_dl", 0) else users(ctx).optJSONObject(me)?.optInt("dl", 0) ?: 0
    }

    fun historyText(ctx: Context): String {
        val arr = try { JSONArray(userPrefs(ctx).getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) return ctx.getString(R.string.history_empty)
        val f = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        return (0 until minOf(arr.length(), 20)).joinToString("\n") {
            val o = arr.getJSONObject(it)
            (if (o.optBoolean("a")) "♪ " else "▶ ") + o.optString("t") + "\n    " + f.format(Date(o.optLong("ts")))
        }
    }

    fun clearHistory(ctx: Context) { userPrefs(ctx).edit().remove("history").apply() }

    fun fmtDate(ts: Long): String = if (ts <= 0) "-" else SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(ts))

    // ---------- انتخاب کیفیت ----------

    fun qualityLabel(ctx: Context, h: Int) = if (h <= 0) ctx.getString(R.string.quality_best) else "${h}p"

    fun pickQuality(ctx: Context, cur: Int, onPick: (Int) -> Unit) {
        val labels = QUALITIES.map { qualityLabel(ctx, it) }.toTypedArray()
        AlertDialog.Builder(ctx)
            .setTitle(R.string.quality_dlg_title)
            .setSingleChoiceItems(labels, QUALITIES.indexOf(cur)) { d, w -> onPick(QUALITIES[w]); d.dismiss() }
            .setNegativeButton(R.string.proxy_cancel, null)
            .show()
    }
}
