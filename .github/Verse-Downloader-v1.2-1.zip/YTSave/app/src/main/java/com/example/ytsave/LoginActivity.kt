package com.example.ytsave

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.ytsave.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var b: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.guest.visibility = if (Accounts.settings(this).allow) View.VISIBLE else View.GONE
        b.login.setOnClickListener { doLogin() }
        b.pass.setOnEditorActionListener { _, _, _ -> doLogin(); true }
        b.guest.setOnClickListener {
            Accounts.logout(this)
            openMain()
        }
    }

    private fun doLogin() {
        val u = b.user.text.toString().trim()
        val p = b.pass.text.toString()
        if (u.isEmpty() || p.isEmpty()) { showError(R.string.login_empty); return }
        when (Accounts.login(this, u, p)) {
            Accounts.LoginResult.OK -> openMain()
            Accounts.LoginResult.DISABLED -> showError(R.string.login_disabled)
            Accounts.LoginResult.BAD -> showError(R.string.login_bad)
        }
    }

    private fun showError(res: Int) {
        b.error.setText(res)
        b.error.visibility = View.VISIBLE
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }
}
