package com.example.ytsave

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ytsave.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {
    private lateinit var b: ActivityProfileBinding
    private var height = 720

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.back.setOnClickListener { finish() }
        b.goLogin.setOnClickListener { goLogin() }
        b.logout.setOnClickListener { Accounts.logout(this); goLogin() }
        b.openAdmin.setOnClickListener { startActivity(Intent(this, AdminActivity::class.java)) }
        b.quality.setOnClickListener {
            Accounts.pickQuality(this, height) { height = it; refreshQuality() }
        }
        b.saveSettings.setOnClickListener { saveSettings() }
        b.clearHistory.setOnClickListener { Accounts.clearHistory(this); b.history.text = Accounts.historyText(this) }
        b.changePw.setOnClickListener { changePwDialog() }
    }

    override fun onResume() {
        super.onResume()
        if (!Accounts.validateSession(this) && !Accounts.settings(this).allow) { goLogin(); return }
        render()
    }

    private fun render() {
        val me = Accounts.current(this)
        val guest = me.isEmpty()
        b.guestCard.visibility = if (guest) View.VISIBLE else View.GONE
        b.accountCard.visibility = if (guest) View.GONE else View.VISIBLE
        b.settingsCard.visibility = if (guest) View.GONE else View.VISIBLE
        b.historyCard.visibility = if (guest) View.GONE else View.VISIBLE
        b.changePw.visibility = if (guest) View.GONE else View.VISIBLE
        b.logout.visibility = if (guest) View.GONE else View.VISIBLE

        if (guest) {
            val s = Accounts.settings(this)
            b.guestInfo.text = getString(
                R.string.guest_info, Accounts.guestUsed(this),
                if (s.limit > 0) s.limit.toString() else "∞", Accounts.qualityLabel(this, s.height)
            )
            return
        }
        b.accountInfo.text = getString(R.string.account_info, me, Accounts.roleLabel(this), Accounts.myDownloads(this))
        b.openAdmin.visibility = if (Accounts.isAdmin(this)) View.VISIBLE else View.GONE
        val p = Accounts.userPrefs(this)
        b.rate.setText(p.getInt("rate", 0).toString())
        height = p.getInt("height", 720)
        refreshQuality()
        b.swWifi.isChecked = p.getBoolean("wifi", false)
        b.swFast.isChecked = p.getBoolean("fast", false)
        b.swMp3.isChecked = p.getBoolean("mp3", false)
        b.history.text = Accounts.historyText(this)
    }

    private fun refreshQuality() {
        b.quality.text = getString(R.string.btn_quality, Accounts.qualityLabel(this, height))
    }

    private fun saveSettings() {
        val rate = b.rate.text.toString().trim().toIntOrNull()?.coerceIn(0, 1_000_000) ?: 0
        Accounts.userPrefs(this).edit()
            .putInt("rate", rate).putInt("height", height)
            .putBoolean("wifi", b.swWifi.isChecked).putBoolean("fast", b.swFast.isChecked)
            .putBoolean("mp3", b.swMp3.isChecked).apply()
        b.rate.setText(rate.toString())
        Toast.makeText(this, R.string.saved_ok, Toast.LENGTH_SHORT).show()
    }

    private fun changePwDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        fun field(h: Int) = EditText(this).apply {
            setHint(h)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val old = field(R.string.hint_old_pw); val new = field(R.string.hint_new_pw)
        box.addView(old); box.addView(new)
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_change_pw)
            .setView(box)
            .setPositiveButton(R.string.btn_save) { _, _ ->
                val err = Accounts.changePassword(this, old.text.toString(), new.text.toString())
                Toast.makeText(this, err ?: R.string.pw_changed, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(R.string.proxy_cancel, null)
            .show()
    }

    private fun goLogin() {
        startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }
}
