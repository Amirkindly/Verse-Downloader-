package com.example.ytsave

import android.app.Application
import android.content.Context
import android.net.Uri
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/** آماده‌سازی موتور دانلود یک بار و در پس‌زمینه (هم‌زمان با صفحه‌ی ورود) */
object Engine {
    val ready = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
}

/** به‌روزرسانی yt-dlp (کانال nightly) با عبور از پراکسی برنامه در صورت وجود */
object Updater {
    @Synchronized
    fun update(ctx: Context): String {
        val app = ctx.applicationContext
        val sp = app.getSharedPreferences("ytsave", Context.MODE_PRIVATE)
        val px = try { Xray.effectiveProxy(app, sp.getString("proxy", "").orEmpty()) } catch (_: Exception) { null }
        val keys = listOf("socksProxyHost", "socksProxyPort", "http.proxyHost", "http.proxyPort", "https.proxyHost", "https.proxyPort")
        val saved = keys.associateWith { System.getProperty(it) }
        try {
            if (px != null) {
                val u = Uri.parse(px)
                val host = u.host ?: "127.0.0.1"
                val port = (if (u.port > 0) u.port else 1080).toString()
                if (px.startsWith("socks", true)) {
                    System.setProperty("socksProxyHost", host); System.setProperty("socksProxyPort", port)
                } else {
                    System.setProperty("http.proxyHost", host); System.setProperty("http.proxyPort", port)
                    System.setProperty("https.proxyHost", host); System.setProperty("https.proxyPort", port)
                }
            }
            val st = YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.NIGHTLY)
            sp.edit().putLong("yt_upd", System.currentTimeMillis()).apply()
            return st.toString()
        } finally {
            saved.forEach { (k, v) -> if (v == null) System.clearProperty(k) else System.setProperty(k, v) }
        }
    }

    fun due(ctx: Context): Boolean {
        val last = ctx.applicationContext.getSharedPreferences("ytsave", Context.MODE_PRIVATE).getLong("yt_upd", 0)
        return System.currentTimeMillis() - last > 12L * 3600 * 1000
    }
}

class VerseApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CoroutineScope(Dispatchers.IO).launch {
            // اگر کاربر کانفیگ V2Ray ذخیره کرده، هسته را همین ابتدا روشن کن
            try {
                val raw = getSharedPreferences("ytsave", MODE_PRIVATE).getString("proxy", "").orEmpty()
                if (raw.isNotBlank()) Xray.configure(applicationContext, raw)
            } catch (_: Exception) {}
        }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                Engine.ready.value = true
                // به‌روزرسانی خودکار و بی‌صدای موتور دانلود (حداکثر هر ۱۲ ساعت)
                if (Updater.due(applicationContext)) {
                    try { Updater.update(applicationContext) } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                Engine.error.value = e.message ?: "unknown"
            }
        }
    }
}
