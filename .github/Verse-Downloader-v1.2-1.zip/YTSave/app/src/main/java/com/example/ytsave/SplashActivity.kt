package com.example.ytsave

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.example.ytsave.databinding.ActivitySplashBinding

class SplashActivity : AppCompatActivity() {

    private var floatAnim: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(b.root)

        // لوگو: ظاهر شدن با پرش ملایم، بعد شناور شدن
        b.logo.alpha = 0f
        b.logo.scaleX = 0.6f
        b.logo.scaleY = 0.6f
        b.logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(900).setInterpolator(OvershootInterpolator(1.4f))
            .withEndAction {
                floatAnim = ObjectAnimator.ofFloat(b.logo, "translationY", 0f, -14f).apply {
                    duration = 1800
                    repeatMode = ObjectAnimator.REVERSE
                    repeatCount = ObjectAnimator.INFINITE
                    start()
                }
            }.start()

        // بقیه‌ی المان‌ها یکی‌یکی ظاهر می‌شوند
        listOf<View>(b.title, b.tagline, b.chips, b.start, b.credit).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 30f
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(350L + i * 150L).setDuration(500).start()
        }

        b.langBtn.setOnClickListener { LocaleHelper.toggle(this) }

        b.start.setOnClickListener {
            startActivity(Intent(this, if (Accounts.validateSession(this)) MainActivity::class.java else LoginActivity::class.java))
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        floatAnim?.cancel()
    }
}
